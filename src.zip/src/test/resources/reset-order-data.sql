-- データ削除
DELETE FROM order_item;
DELETE FROM `order`;

