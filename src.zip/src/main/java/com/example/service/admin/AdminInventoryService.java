package com.example.service.admin;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.dto.admin.AdminInventoryListDto;
import com.example.mapper.admin.AdminInventoryMapper;
import com.example.request.admin.InventorySearchRequest;
import com.example.util.PaginationUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminInventoryService {
    // TODO:
    // 発注画面
    //    第1段階（最小）：表示 ➜ ロック ➜ 手動調整
    //    第2段階：フィルタ／並び替え／検索
    //    第3段階：CSVエクスポート・ページネーション・監査ログ
    //    第4段階（拡張）：商品別閾値・在庫履歴・倉庫別在庫

    private final AdminInventoryMapper adminInventoryMapper;

    @Value("${settings.admin.inventory.size}")
    private int pageSize;

    @Value("${settings.admin.inventory.low-stock-threshold}")
    private int threshold;

    public AdminInventoryListDto search(InventorySearchRequest req) {
        int offset = PaginationUtil.calculateOffset(req.getPage(), pageSize);

        return new AdminInventoryListDto(
                adminInventoryMapper.search(req, threshold, pageSize, offset),
                adminInventoryMapper.count(req, threshold),
                pageSize);
    }
}
