package com.example.enums;

public enum SortDirection {
    ASC,
    DESC;
}
