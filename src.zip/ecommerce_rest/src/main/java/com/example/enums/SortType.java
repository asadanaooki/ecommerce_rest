package com.example.enums;

public enum SortType {
    NEW,
    HIGH,
    LOW
}
