package com.example.enums;

public enum StockStatus {
    OUT_OF_STOCK,
    LOW_STOCK,
    IN_STOCK
}
