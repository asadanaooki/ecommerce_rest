package com.example.enums;

public enum PaymentStatus {
    UNPAID,
    PAID
}
