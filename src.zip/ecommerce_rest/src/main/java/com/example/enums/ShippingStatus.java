package com.example.enums;

public enum ShippingStatus {
    NOT_SHIPPED,
    SHIPPED

}
