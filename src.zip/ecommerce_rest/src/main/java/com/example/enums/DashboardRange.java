package com.example.enums;

public enum DashboardRange {
    TODAY,
    LAST_7_DAYS_INCLUDING_TODAY,
    MONTH_TO_DATE
}
