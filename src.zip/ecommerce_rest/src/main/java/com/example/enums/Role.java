package com.example.enums;

public enum Role {
    USER,
    ADMIN
}
